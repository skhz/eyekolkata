<div id="top">
    <!-- Logo -->
    <div class="logo"> 
        <a href="#" title="Administration Home" class="tooltip"><img src="images/logo.png" alt="Wide Admin" /></a> 
    </div>
    <!-- End of Logo -->
    
    <!-- Meta information -->
    <div class="meta">

        <p>Loged user : admin <!--<a href="#" title="1 new private message from Elaine!" class="tooltip">1 new message!</a>--></p>
        <ul>
            <li><a href="logoff.php" title="" class="tooltip"><span class="ui-icon ui-icon-power"></span>Logout</a></li>
            <li><a href="#" title="Go to your account" class="tooltip"><span class="ui-icon ui-icon-person"></span>My account</a></li>
        	<li><a href="../" target="_blank" title="Change current settings" class="tooltip"><span class="ui-icon ui-icon-wrench"></span>Site Home</a></li>
            </ul>	
    </div>

  <!-- End of Meta information -->
</div>
