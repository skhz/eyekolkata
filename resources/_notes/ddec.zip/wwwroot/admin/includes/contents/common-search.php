<div id="search">
    <form action="/search/" method="POST">
        <p>
            <input type="submit" value="" class="but" />
            <input type="text" name="q" value="Search for orders" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" />
        </p>
    </form>
</div>