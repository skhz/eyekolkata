<div id="navbar">
    <ul id="nav" class="dropdown dropdown-horizontal">
        <li><a href="index.php">Home</a></li>
        <li><a href="javascript:void(0);" class="dir">CMS Pages</a>
            <ul>
                <li><a href="add-edit-cms-page.php">Add CMS Page</a></li>
                <li><a href="view-cms-pages.php">View CMS Pages</a></li>
            </ul>
        </li>
        <li><a href="javascript:void(0);" class="dir">FAQ</a>
            <ul>
                <li><a href="add-edit-faq.php">Add FAQ</a></li>
                <li><a href="view-faq.php">View FAQ</a></li>
            </ul>
        </li>
        <!--<li><a href="./" class="dir">Product Section</a>
            <ul>
                <li class="empty">Product</li>
                <li><a href="javascript:void(0);">Add Product</a></li>
                <li><a href="javascript:void(0);">View Products</a></li>
                <li class="empty">Category</li>
                <li><a href="javascript:void(0);">Add Category</a></li>
                <li><a href="javascript:void(0);">View Categories</a></li>
                <li class="empty">Manufacturer</li>
                <li><a href="javascript:void(0);">Add Manufacturer</a></li>
                <li><a href="javascript:void(0);">View Manufacturer</a></li>
                
            </ul>
        </li>-->
        <li><a href="enquiry.php" class="dir">Enquiry</a></li>
        <li><a href="javascript:void(0);" class="dir">Settings</a></li>
    </ul>
</div>