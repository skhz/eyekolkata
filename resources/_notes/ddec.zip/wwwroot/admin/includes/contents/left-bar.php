<!-- Navigation Tree -->
<?php include_once(LEFT_BAR.'navigation-tree.php'); ?>
<!-- End of navigation Tree -->

<!-- Accordion -->
<?php include_once(LEFT_BAR.'accordion.php'); ?>
<!-- End of Accordion-->