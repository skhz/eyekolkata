<div class="wrapper col4">
  <div id="header">
   	<div id="topnav" style="float:left">
      <ul>
      	  <li <?php if($link==1){?>  class="active"  <?php }?>><a href="index.php">Home</a></li>
                <li <?php if($link==2){?>  class="active"  <?php }?>><a href="about_us.php">About Us</a></li>
                <li <?php if($link==3){?>  class="active"  <?php }?>><a href="clinic.php">Clinic</a></li>
                <li <?php if($link==4){?>  class="active"  <?php }?>><a href="Javascript: void(0)">Eye Disease</a></li>
                <li <?php if($link==5){?>  class="active"  <?php }?>><a href="Javascript: void(0)">Contact Lens</a></li>
                <li <?php if($link==6){?>  class="active"  <?php }?>><a href="surgery.php">Surgery</a></li>
                <li <?php if($link==7){?>  class="active"  <?php }?>><a href="eye_care.php">Eye Care</a></li>
                <li <?php if($link==8){?>  class="active"  <?php }?>><a href="faq.php">FAQ</a></li>
                <li <?php if($link==9){?>  class="active"  <?php }?>class="last"><a href="contact_us.php">Contact</a></li>
      </ul>
     </div>
     <div id="logo" style="padding:1px 0 0 0;">
        <img src="images/helpline.jpg" />
   	</div>
    <br class="clear" />
  </div>
</div>
