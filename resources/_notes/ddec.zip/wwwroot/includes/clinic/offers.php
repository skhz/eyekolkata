<div class="holder">
    <h2 class="title"><img src="images/clinic/offersheader.jpg" /></h2>
    <table cellspacing="3">
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Auto Perimetry</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Auto Refraction</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Ultrasonic A-Scan Biometry</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Indirect Ophthalmoscopy</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Slit Lamp Biomicroscopy</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Keratomerty</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Lensometry</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>3-Mirror Gonioscopy</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Applanation Tonometry</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
        
        <tr>
            <td width="16"><img src="images/clinic/Favorites_16x16.png" /></td>
            <td width="269"><strong>Contact Lens</strong></td>
        </tr>
        <tr>
            <td colspan="2">Urnau ltrices quis curabitur pha sellent esque congue magnisve stib ulum quismodo nulla et feugiat. Adipisciniap ellentum leo ut consequam. </td>
        </tr>
    </table>
</div>