<div id="footer">
    <p class="mid">
        <a href="#" title="Top" class="tooltip">Top</a>&middot;<a href="index.php" title="Main Page" class="tooltip">Home</a>&middot;<a href="#" title="Change current settings" class="tooltip">Settings</a>&middot;<a href="logoff.php" title="End administrator session" class="tooltip">Logout</a></p>
    <p class="mid">
        &copy; eyekolkata.com 2010. All rights reserved.
    </p>
</div>