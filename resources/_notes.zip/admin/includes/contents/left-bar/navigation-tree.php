<h2>Navigation Area</h2>
<ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="javascript:void(0);">CMS Pages</a>
        <ul>
            <li><a href="add-edit-cms-page.php">Add CMS Page</a></li>
            <li><a href="view-cms-pages.php">View CMS Pages</a></li>
        </ul>
    </li>
    <li><a href="javascript:void(0);">FAQ</a>
        <ul>
            <li><a href="add-edit-faq.php">Add FAQ</a></li>
            <li><a href="view-faq.php">View FAQs</a></li>
        </ul>
    </li>
    <li><a href="enquiry.php">Enquiry</a></li>
    <li><a href="">Settings</a></li>
</ul>