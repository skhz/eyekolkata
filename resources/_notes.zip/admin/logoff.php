<?php 
include("config.php");
unset($_SESSION['admin']);
redirect('login.php');
?>